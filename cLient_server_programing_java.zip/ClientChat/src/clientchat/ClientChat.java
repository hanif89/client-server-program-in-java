
import java.io.*;
import java.net.*;

public class ClientChat {

    public static void main(String[] args) {
        try {
            Socket s = new Socket("127.0.0.1", 6666);
            DataInputStream din = new DataInputStream(s.getInputStream());
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String str1 = "";
            String str2 = "";
            while (!str1.equals("Bye")) {
                str1 = br.readLine();
                dout.writeUTF(str1);
                dout.flush();
                str2 = din.readUTF();
                System.out.println("Server Says: " + str2);
            }
            s.close();
        } catch (Exception e) {
            System.out.println(e);

        }
    }
}
