
import java.net.*;
import java.io.*;

public class ServerChat {

    public static void main(String[] args) {
		try{
		ServerSocket ss =new ServerSocket(6666);
		Socket s = ss.accept();
		DataInputStream din = new DataInputStream(s.getInputStream());
		DataOutputStream dout = new DataOutputStream(s.getOutputStream());
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str1 ="";
		String str2 ="";
		while(!str1.equals("Bye"))
		{
			str1 = din.readUTF();
		System.out.println("Client Says: " + str1);
		str2 = br.readLine();
		dout.writeUTF(str2);
		dout.flush();
		}
		ss.close();
		s.close();
		}
		catch (Exception e){
			System.out.println(e);
			
		}
		
	}
}
